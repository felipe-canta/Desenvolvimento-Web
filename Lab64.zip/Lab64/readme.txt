1.	Instalar o Express:
Primeiro, instale o Express, que facilita o gerenciamento de rotas e o serviço de arquivos estáticos.
No terminal, execute:

npm install express

2.	Estrutura de Diretórios:
Crie uma estrutura de diretórios onde seus arquivos HTML e CSS estarão. Por exemplo:

Estrutura de Diretórios Completa:

├── server.js
├── public
    ├── index.html
    ├── about.html
    ├── styles.css

